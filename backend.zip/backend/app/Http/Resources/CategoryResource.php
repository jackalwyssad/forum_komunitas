<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'description'   => $this->description,
            'is_public'     => $this->is_public,
            'threads_count' => $this->whenCounted('threads'),
            'created_at'    => $this->created_at->toISOString(),
        ];
    }
}
